// Copyright Epic Games, Inc. All Rights Reserved.


#include "Variant_Shooter/ShooterBulletCounterUI.h"

