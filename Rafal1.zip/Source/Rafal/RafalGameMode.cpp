// Copyright Epic Games, Inc. All Rights Reserved.

#include "RafalGameMode.h"

ARafalGameMode::ARafalGameMode()
{
	// stub
}
